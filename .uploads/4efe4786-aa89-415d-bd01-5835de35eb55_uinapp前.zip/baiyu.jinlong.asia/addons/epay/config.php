<?php

return array (
  0 => 
  array (
    'name' => 'version',
    'title' => 'API版本(请勿修改该值)',
    'type' => 'radio',
    'content' => 
    array (
    ),
    'value' => 'v2',
    'rule' => '',
    'msg' => '',
    'tip' => 'V2版本只支持微信支付V2密钥，V3版本只支持微信支付V3密钥，请勿修改该值！！！',
    'ok' => '',
    'extend' => '',
  ),
  1 => 
  array (
    'name' => 'wechat',
    'title' => '微信',
    'type' => 'array',
    'content' => 
    array (
    ),
    'value' => 
    array (
      'appid' => '',
      'app_id' => '',
      'app_secret' => '',
      'miniapp_id' => 'wx963a7645f63bbd0c',
      'mch_id' => '1106476594',
      'key' => '20240229202503152010062820100328',
      'key_v3' => '',
      'public_key_id' => '',
      'public_key' => '/addons/epay/certs/public_key.pem',
      'cert_client' => '/uploads/cert/20260216/16ef97541c1518bbfd2536a1713955de.pem',
      'cert_key' => '/uploads/cert/20260216/da4aab83999c342da28720d24cb2f9af.pem',
      'mode' => 'normal',
      'sub_mch_id' => '',
      'sub_appid' => '',
      'sub_app_id' => '',
      'sub_miniapp_id' => '',
      'notify_url' => '',
      'log' => '1',
    ),
    'rule' => 'required',
    'msg' => '',
    'tip' => '微信参数配置',
    'ok' => '',
    'extend' => '',
  ),
  2 => 
  array (
    'name' => 'alipay',
    'title' => '支付宝',
    'type' => 'array',
    'content' => 
    array (
    ),
    'value' => 
    array (
      'app_id' => '',
      'mode' => 'normal',
      'notify_url' => '/addons/epay/api/notifyx/type/alipay',
      'return_url' => '/addons/epay/api/returnx/type/alipay',
      'private_key' => '',
      'signtype' => 'cert',
      'pid' => '',
      'ali_public_key' => '',
      'app_cert_public_key' => '',
      'alipay_root_cert' => '',
      'log' => '1',
      'scanpay' => '0',
    ),
    'rule' => 'required',
    'msg' => '',
    'tip' => '支付宝参数配置',
    'ok' => '',
    'extend' => '',
  ),
);
