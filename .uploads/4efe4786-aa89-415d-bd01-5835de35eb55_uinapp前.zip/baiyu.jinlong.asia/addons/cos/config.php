<?php

return array (
  0 => 
  array (
    'name' => 'appId',
    'title' => 'AppID',
    'type' => 'string',
    'content' => 
    array (
    ),
    'value' => '1365505900',
    'rule' => 'required',
    'msg' => '',
    'tip' => '请前往腾讯控制台 > 访问管理 > API密钥',
    'ok' => '',
    'extend' => '',
  ),
  1 => 
  array (
    'name' => 'secretId',
    'title' => 'SecretId',
    'type' => 'string',
    'content' => 
    array (
    ),
    'value' => 'AKIDqZ6UfFl5MQIxY9vkaJqOn09A1hASbl0G',
    'rule' => 'required',
    'msg' => '',
    'tip' => '请前往腾讯控制台 > 访问管理 > API密钥',
    'ok' => '',
    'extend' => '',
  ),
  2 => 
  array (
    'name' => 'secretKey',
    'title' => 'SecretKey',
    'type' => 'string',
    'content' => 
    array (
    ),
    'value' => 'PsJagaJp7HG3cy79ECB7sSpz02wkNmy0',
    'rule' => 'required',
    'msg' => '',
    'tip' => '请前往腾讯控制台 > 访问管理 > API密钥',
    'ok' => '',
    'extend' => '',
  ),
  3 => 
  array (
    'name' => 'bucket',
    'title' => '存储桶名称',
    'type' => 'string',
    'content' => 
    array (
    ),
    'value' => 'dianjing-1365505900',
    'rule' => 'required;bucket',
    'msg' => '',
    'tip' => '存储空间名称',
    'ok' => '',
    'extend' => 'data-rule-bucket="[/^[0-9a-z_\\-]{3,63}$/, \'请输入正确的存储桶名称\']"',
  ),
  4 => 
  array (
    'name' => 'region',
    'title' => '地域名称',
    'type' => 'string',
    'content' => 
    array (
    ),
    'value' => 'ap-guangzhou',
    'rule' => 'required',
    'msg' => '',
    'tip' => '请输入地域简称,请注意使用英文',
    'ok' => '',
    'extend' => '',
  ),
  5 => 
  array (
    'name' => 'uploadmode',
    'title' => '上传模式',
    'type' => 'select',
    'content' => 
    array (
      'client' => '客户端直传(速度快,无备份)',
      'server' => '服务器中转(占用服务器带宽,有备份)',
    ),
    'value' => 'server',
    'rule' => '',
    'msg' => '',
    'tip' => '',
    'ok' => '',
    'extend' => '',
  ),
  6 => 
  array (
    'name' => 'serverbackup',
    'title' => '服务器中转模式备份',
    'type' => 'radio',
    'content' => 
    array (
      1 => '备份(附件管理将产生2条记录)',
      0 => '不备份',
    ),
    'value' => '1',
    'rule' => '',
    'msg' => '',
    'tip' => '服务器中转模式下是否备份文件',
    'ok' => '',
    'extend' => '',
  ),
  7 => 
  array (
    'name' => 'uploadurl',
    'title' => '上传接口地址',
    'type' => 'string',
    'content' => 
    array (
    ),
    'value' => 'https://dianjing-1365505900.cos.ap-guangzhou.myqcloud.com',
    'rule' => 'required;uploadurl',
    'msg' => '',
    'tip' => '请输入你的上传接口地址',
    'ok' => '',
    'extend' => 'data-rule-uploadurl="[/^http(s)?:\\/\\/.*$/, \'必需以http(s)://开头\']"',
  ),
  8 => 
  array (
    'name' => 'cdnurl',
    'title' => 'CDN地址',
    'type' => 'string',
    'content' => 
    array (
    ),
    'value' => 'https://dianjing-1365505900.cos.ap-guangzhou.myqcloud.com',
    'rule' => 'required;cdnurl',
    'msg' => '',
    'tip' => '请配置你的CDN地址或在存储桶基础配置中获取',
    'ok' => '',
    'extend' => 'data-rule-cdnurl="[/^http(s)?:\\/\\/.*$/, \'必需以http(s)://开头\']"',
  ),
  9 => 
  array (
    'name' => 'savekey',
    'title' => '保存文件名',
    'type' => 'string',
    'content' => 
    array (
    ),
    'value' => '/uploads/{year}{mon}{day}/{filemd5}{.suffix}',
    'rule' => 'required',
    'msg' => '',
    'tip' => '',
    'ok' => '',
    'extend' => '',
  ),
  10 => 
  array (
    'name' => 'expire',
    'title' => '上传有效时长',
    'type' => 'string',
    'content' => 
    array (
    ),
    'value' => '600',
    'rule' => 'required',
    'msg' => '',
    'tip' => '用户停留页面上传有效时长，单位秒',
    'ok' => '',
    'extend' => '',
  ),
  11 => 
  array (
    'name' => 'maxsize',
    'title' => '最大可上传',
    'type' => 'string',
    'content' => 
    array (
    ),
    'value' => '10M',
    'rule' => 'required',
    'msg' => '',
    'tip' => '',
    'ok' => '',
    'extend' => '',
  ),
  12 => 
  array (
    'name' => 'mimetype',
    'title' => '可上传后缀格式',
    'type' => 'string',
    'content' => 
    array (
    ),
    'value' => 'jpg,png,bmp,jpeg,gif,zip,rar',
    'rule' => 'required',
    'msg' => '',
    'tip' => '',
    'ok' => '',
    'extend' => '',
  ),
  13 => 
  array (
    'name' => 'multiple',
    'title' => '多文件上传',
    'type' => 'bool',
    'content' => 
    array (
    ),
    'value' => '0',
    'rule' => 'required',
    'msg' => '',
    'tip' => '',
    'ok' => '',
    'extend' => '',
  ),
  14 => 
  array (
    'name' => 'thumbstyle',
    'title' => '缩略图样式',
    'type' => 'string',
    'content' => 
    array (
    ),
    'value' => '',
    'rule' => '',
    'msg' => '',
    'tip' => '用于后台列表缩略图样式，可使用：?imageMogr2/thumbnail/120x90',
    'ok' => '',
    'extend' => '',
  ),
  15 => 
  array (
    'name' => 'chunking',
    'title' => '分片上传',
    'type' => 'radio',
    'content' => 
    array (
      1 => '开启',
      0 => '关闭',
    ),
    'value' => '0',
    'rule' => 'required',
    'msg' => '',
    'tip' => '',
    'ok' => '',
    'extend' => '',
  ),
  16 => 
  array (
    'name' => 'chunksize',
    'title' => '分片大小',
    'type' => 'number',
    'content' => 
    array (
    ),
    'value' => '4194304',
    'rule' => 'required',
    'msg' => '',
    'tip' => '',
    'ok' => '',
    'extend' => '',
  ),
  17 => 
  array (
    'name' => 'syncdelete',
    'title' => '附件删除时是否同步删除云存储文件',
    'type' => 'bool',
    'content' => 
    array (
    ),
    'value' => '0',
    'rule' => 'required',
    'msg' => '',
    'tip' => '',
    'ok' => '',
    'extend' => '',
  ),
  18 => 
  array (
    'name' => 'apiupload',
    'title' => 'API接口使用云存储',
    'type' => 'bool',
    'content' => 
    array (
    ),
    'value' => '1',
    'rule' => 'required',
    'msg' => '',
    'tip' => '',
    'ok' => '',
    'extend' => '',
  ),
  19 => 
  array (
    'name' => 'noneedlogin',
    'title' => '免登录上传',
    'type' => 'checkbox',
    'content' => 
    array (
      'api' => 'API',
      'index' => '前台',
      'admin' => '后台',
    ),
    'value' => '',
    'rule' => '',
    'msg' => '',
    'tip' => '',
    'ok' => '',
    'extend' => '',
  ),
);
